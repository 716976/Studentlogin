<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CLASH OF CLANS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="img/propic.jpg" type="image/icon type">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Clash of Clans</div>
            <ul class="nav-links">
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#download">Download</a></li>
            </ul>
            <div class="hamburger">
                <i class="fas fa-bars"></i>
            </div>
        </nav>
    </header>

    <section id="home" class="section">
        <h1>Welcome to Clash of Clans</h1>
        <h2>Build your village, train your troops, and conquer the world!</h2>
    </section>

    <section id="about" class="section">
        <h1>About Clash of Clans</h1>
        <div class="about-content">
            <img src="img/coc1.jpg" alt="Clash of Clans" class="about-img">
            <p>Clash of Clans is a freemium mobile strategy game where players build their own village, train troops, and attack other players' villages to earn resources. The game combines base-building, resource management, and real-time strategy elements.</p>
        </div>
    </section>

    <section id="download" class="section">
        <h1>Download Clash of Clans</h1>
        <p>Click the link below to download Clash of Clans:</p>
        <a href="https://play.google.com/store/apps/details?id=com.supercell.clashofclans" target="_blank" class="download-btn">
            Download Clash of Clans from Google Play Store
        </a>
    </section>

    <footer>
        <p>&copy; 2025 Clash of Clans. All rights reserved.</p>
    </footer>

    <script>
        
        const hamburger = document.querySelector('.hamburger');
        const navLinks = document.querySelector('.nav-links');

        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    </script>
</body>
</html>