<?php
// registration.php
session_start();
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve input values
    $student_id = trim($_POST['student_id']);
    $fullname   = trim($_POST['fullname']);
    $email      = trim($_POST['email']);
    $phone      = trim($_POST['phone']);
    $gender     = trim($_POST['gender']);
    $course     = trim($_POST['course']);
    $password   = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if passwords match
    if ($password !== $confirm_password) {
        die("Error: Passwords do not match.");
    }

    // Optionally, add further validations (e.g., proper email format)

    // Hash the password securely
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare the SQL statement using named parameters
    $sql = "INSERT INTO students (student_id, fullname, email, phone, gender, course, password) 
            VALUES (:student_id, :fullname, :email, :phone, :gender, :course, :password)";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([
            ':student_id' => $student_id,
            ':fullname'   => $fullname,
            ':email'      => $email,
            ':phone'      => $phone,
            ':gender'     => $gender,
            ':course'     => $course,
            ':password'   => $hashed_password,
        ]);
        // Optionally, log the user in immediately after registration
        $_SESSION['user_id'] = $pdo->lastInsertId();
        $_SESSION['fullname'] = $fullname;
        header("Location: dashboard.php");
        exit();
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>
