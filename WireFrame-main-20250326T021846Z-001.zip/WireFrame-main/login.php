<?php
session_start(); 


$host = "localhost";
$username = "root"; 
$password = ""; 
$database = "student_registration";

$conn = new mysqli($host, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $student_id = $_POST['student_id'];
    $password = $_POST['password'];

    
    $sql = "SELECT id, student_id, password FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        if (password_verify($password, $row['password'])) {
        
            $_SESSION['student_id'] = $row['student_id'];
            $_SESSION['student_db_id'] = $row['id']; 
            header("Location: dashboard.php"); 
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "Student ID not found.";
    }

    $stmt->close();
}

$conn->close();
?>
